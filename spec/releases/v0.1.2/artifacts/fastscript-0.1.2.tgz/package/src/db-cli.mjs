import { existsSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { createFileDatabase } from "./db.mjs";
import { importSourceModule } from "./module-loader.mjs";

const FASTSCRIPT_DIR = resolve(".fastscript");
const MIGRATIONS_DIR = resolve("app/db/migrations");
const MIGRATION_LEDGER = join(FASTSCRIPT_DIR, "migrations.json");
const SEED_FILES = [resolve("app/db/seed.fs"), resolve("app/db/seed.js"), resolve("app/db/seed.mjs"), resolve("app/db/seed.cjs")];

function readLedger() {
  if (!existsSync(MIGRATION_LEDGER)) return { applied: [] };
  try {
    const raw = JSON.parse(readFileSync(MIGRATION_LEDGER, "utf8"));
    return { applied: Array.isArray(raw.applied) ? raw.applied : [] };
  } catch {
    return { applied: [] };
  }
}

function writeLedger(applied) {
  mkdirSync(FASTSCRIPT_DIR, { recursive: true });
  writeFileSync(MIGRATION_LEDGER, JSON.stringify({ applied: [...new Set(applied)].sort() }, null, 2), "utf8");
}

export async function runDbMigrate() {
  const db = createFileDatabase({ dir: ".fastscript", name: "appdb" });
  if (!existsSync(MIGRATIONS_DIR)) {
    console.log("db migrate: no app/db/migrations directory");
    return;
  }

  const done = new Set(readLedger().applied);
  const files = readdirSync(MIGRATIONS_DIR).filter((f) => /\.(fs|js|mjs|cjs)$/.test(f)).sort();
  let count = 0;

  for (const file of files) {
    if (done.has(file)) {
      console.log(`db migrate: skipped ${file} (already applied)`);
      continue;
    }
    const mod = await importSourceModule(join(MIGRATIONS_DIR, file), { platform: "node" });
    const fn = mod.up ?? mod.default;
    if (typeof fn !== "function") continue;
    await fn(db);
    done.add(file);
    writeLedger([...done]);
    count += 1;
    console.log(`db migrate: applied ${file}`);
  }

  console.log(`db migrate complete: ${count} migration(s)`);
}

export async function runDbSeed() {
  const db = createFileDatabase({ dir: ".fastscript", name: "appdb" });
  const seedFile = SEED_FILES.find((p) => existsSync(p));
  if (!seedFile) {
    console.log("db seed: no app/db/seed file");
    return;
  }
  const mod = await importSourceModule(seedFile, { platform: "node" });
  const fn = mod.seed ?? mod.default;
  if (typeof fn !== "function") throw new Error("app/db/seed must export seed(db) or default(db)");
  await fn(db);
  console.log("db seed complete");
}
