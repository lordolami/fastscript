function makeDiagnostic(file, line, column, code, message) {
  return { file, line, column, code, message };
}

function displayPath(file) {
  return file || "<memory>";
}

export function analyzeFastScript(source, { file = "" } = {}) {
  const diagnostics = [];
  const lines = String(source || "").split(/\r?\n/);

  for (let i = 0; i < lines.length; i += 1) {
    const line = lines[i];
    const trimmed = line.trim();

    if (/^\s*~/.test(line) && !/^\s*~[A-Za-z_$][\w$]*\s*=/.test(line)) {
      diagnostics.push(
        makeDiagnostic(
          file,
          i + 1,
          line.indexOf("~") + 1,
          "FS1001",
          "Reactive declaration must be `~name = value`.",
        ),
      );
    }

    if (/^\s*state\b/.test(line) && !/^\s*state\s+[A-Za-z_$][\w$]*\s*=/.test(line)) {
      diagnostics.push(
        makeDiagnostic(
          file,
          i + 1,
          line.indexOf("state") + 1,
          "FS1002",
          "State declaration must be `state name = value`.",
        ),
      );
    }

    if (/^\s*fn\b/.test(line) && !/^\s*(export\s+)?fn\s+[A-Za-z_$][\w$]*\s*\(/.test(line)) {
      diagnostics.push(
        makeDiagnostic(
          file,
          i + 1,
          line.indexOf("fn") + 1,
          "FS1003",
          "Function declaration must be `fn name(...)`.",
        ),
      );
    }

    if (/^\s*(interface|enum|type)\b/.test(line)) {
      diagnostics.push(
        makeDiagnostic(
          file,
          i + 1,
          Math.max(1, line.search(/\S/) + 1),
          "FS1004",
          "TypeScript type declarations are not supported directly in .fs. Use `fastscript migrate` first.",
        ),
      );
    }

    if (trimmed.includes("TODO_ERROR")) {
      diagnostics.push(
        makeDiagnostic(file, i + 1, line.indexOf("TODO_ERROR") + 1, "FS1999", "Remove TODO_ERROR token."),
      );
    }
  }

  return diagnostics;
}

export function assertFastScript(source, { file = "" } = {}) {
  const diagnostics = analyzeFastScript(source, { file });
  if (!diagnostics.length) return;
  const primary = diagnostics[0];
  const path = displayPath(primary.file);
  const details = diagnostics.map((d) => `${displayPath(d.file)}:${d.line}:${d.column} ${d.code} ${d.message}`).join("\n");
  const error = new Error(`${path}:${primary.line}:${primary.column} ${primary.code} ${primary.message}\n${details}`);
  error.status = 1;
  error.details = diagnostics;
  throw error;
}
