import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
import { randomUUID } from "node:crypto";
import { importSourceModule } from "./module-loader.mjs";

function readJson(path, fallback) {
  if (!existsSync(path)) return fallback;
  try { return JSON.parse(readFileSync(path, "utf8")); } catch { return fallback; }
}

function writeJson(path, value) {
  writeFileSync(path, JSON.stringify(value, null, 2), "utf8");
}

export function createJobQueue({ dir = ".fastscript" } = {}) {
  const root = resolve(dir);
  mkdirSync(root, { recursive: true });
  const jobsPath = join(root, "jobs.json");
  const deadPath = join(root, "jobs-dead-letter.json");
  const state = readJson(jobsPath, { jobs: [] });
  const dead = readJson(deadPath, { jobs: [] });

  function persist() { writeJson(jobsPath, state); }
  function persistDead() { writeJson(deadPath, dead); }

  return {
    enqueue(name, payload = {}, opts = {}) {
      const now = Date.now();
      const delayMs = opts.delayMs ?? 0;
      const dedupeKey = opts.dedupeKey || null;
      if (dedupeKey) {
        const duplicate = state.jobs.find((j) => j.name === name && j.dedupeKey === dedupeKey);
        if (duplicate) return duplicate;
      }
      const job = {
        id: randomUUID(),
        name,
        payload,
        runAt: now + delayMs,
        attempts: 0,
        maxAttempts: opts.maxAttempts ?? 3,
        backoffMs: opts.backoffMs ?? 250,
        repeatEveryMs: opts.repeatEveryMs ?? 0,
        dedupeKey,
      };
      state.jobs.push(job);
      persist();
      return job;
    },
    peekReady(limit = 10) {
      const now = Date.now();
      return state.jobs.filter((j) => j.runAt <= now).slice(0, limit);
    },
    ack(id) {
      state.jobs = state.jobs.filter((j) => j.id !== id);
      persist();
    },
    fail(job, error = null) {
      const idx = state.jobs.findIndex((j) => j.id === job.id);
      if (idx < 0) return;
      const current = state.jobs[idx];
      current.attempts += 1;
      if (current.attempts >= current.maxAttempts) {
        dead.jobs.push({
          ...current,
          failedAt: Date.now(),
          error: error ? String(error?.message || error) : null,
        });
        state.jobs.splice(idx, 1);
        persistDead();
      } else {
        current.runAt = Date.now() + current.backoffMs * current.attempts;
      }
      persist();
    },
    list() {
      return [...state.jobs];
    },
    deadLetter() {
      return [...dead.jobs];
    },
  };
}

export async function loadJobHandlers({ root = process.cwd() } = {}) {
  const fs = await import("node:fs");
  const path = await import("node:path");
  const jobsDir = path.join(root, "app", "jobs");
  const handlers = new Map();
  if (!fs.existsSync(jobsDir)) return handlers;
  const files = fs.readdirSync(jobsDir).filter((f) => /\.(fs|js|mjs|cjs)$/.test(f));
  for (const file of files) {
    if (file === "schedules.js" || file === "schedules.fs") continue;
    const full = path.join(jobsDir, file);
    const mod = await importSourceModule(full, { platform: "node" });
    const name = mod.name || file.replace(/\.(fs|js|mjs|cjs)$/, "");
    const handle = mod.handle || mod.default;
    if (typeof handle === "function") handlers.set(name, handle);
  }
  return handlers;
}

export async function loadSchedules({ root = process.cwd() } = {}) {
  const fs = await import("node:fs");
  const path = await import("node:path");
  const jsFile = path.join(root, "app", "jobs", "schedules.js");
  const fsFile = path.join(root, "app", "jobs", "schedules.fs");
  const file = fs.existsSync(fsFile) ? fsFile : jsFile;
  if (!fs.existsSync(file)) return [];
  const mod = await importSourceModule(file, { platform: "node" });
  return mod.schedules || mod.default || [];
}

export async function runWorker({ dir = ".fastscript", pollMs = 350 } = {}) {
  const queue = createJobQueue({ dir });
  const handlers = await loadJobHandlers();
  const schedules = await loadSchedules();
  let inFlight = 0;
  let stopping = false;

  for (const s of schedules) {
    if (!s || !s.name) continue;
    const dedupeKey = `schedule:${s.name}`;
    queue.enqueue(s.name, s.payload || {}, {
      delayMs: s.everyMs ?? 1000,
      maxAttempts: s.maxAttempts ?? 3,
      repeatEveryMs: s.everyMs ?? 0,
      dedupeKey,
    });
  }

  console.log(`worker started: handlers=${handlers.size}`);
  const timer = setInterval(async () => {
    if (stopping) return;
    const jobs = queue.peekReady(20);
    for (const job of jobs) {
      const handle = handlers.get(job.name);
      if (!handle) {
        queue.fail(job, "handler_not_found");
        continue;
      }
      inFlight += 1;
      try {
        await handle(job.payload, { queue });
        if (job.repeatEveryMs > 0) {
          queue.enqueue(job.name, job.payload, {
            delayMs: job.repeatEveryMs,
            maxAttempts: job.maxAttempts,
            backoffMs: job.backoffMs,
            repeatEveryMs: job.repeatEveryMs,
            dedupeKey: job.dedupeKey || null,
          });
        }
        queue.ack(job.id);
      } catch (error) {
        queue.fail(job, error);
      } finally {
        inFlight -= 1;
      }
    }
  }, pollMs);

  async function shutdown() {
    if (stopping) return;
    stopping = true;
    clearInterval(timer);
    const started = Date.now();
    while (inFlight > 0 && Date.now() - started < 3000) {
      await new Promise((r) => setTimeout(r, 50));
    }
    process.exit(0);
  }

  process.on("SIGINT", shutdown);
  process.on("SIGTERM", shutdown);
}
