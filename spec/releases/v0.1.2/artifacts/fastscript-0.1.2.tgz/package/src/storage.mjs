import { createHash } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { dirname, resolve, sep } from "node:path";

function sha(input) {
  return createHash("sha1").update(input).digest("hex");
}

function createKeyResolver(root) {
  const rootPrefix = root.endsWith(sep) ? root : `${root}${sep}`;
  return function safePathFor(key) {
    const normalized = String(key || "").replace(/\\/g, "/").replace(/^\/+/, "");
    if (!normalized || normalized.includes("\0")) {
      const error = new Error("Invalid storage key");
      error.status = 400;
      throw error;
    }
    const abs = resolve(root, normalized);
    if (abs !== root && !abs.startsWith(rootPrefix)) {
      const error = new Error("Invalid storage key path");
      error.status = 400;
      throw error;
    }
    return { abs, normalized };
  };
}

export function createLocalStorage({ dir = ".fastscript/storage" } = {}) {
  const root = resolve(dir);
  mkdirSync(root, { recursive: true });
  const safePathFor = createKeyResolver(root);

  return {
    type: "local",
    put(key, content) {
      const { abs, normalized } = safePathFor(key);
      mkdirSync(dirname(abs), { recursive: true });
      writeFileSync(abs, content);
      return { key: normalized, etag: sha(Buffer.isBuffer(content) ? content : Buffer.from(String(content))) };
    },
    get(key) {
      const { abs } = safePathFor(key);
      if (!existsSync(abs)) return null;
      return readFileSync(abs);
    },
    delete(key) {
      const { abs } = safePathFor(key);
      rmSync(abs, { force: true });
    },
    url(key) {
      const { normalized } = safePathFor(key);
      return `/__storage/${normalized}`;
    },
  };
}

export function createS3CompatibleStorage({ bucket, endpoint, region = "auto", presignBaseUrl } = {}) {
  return {
    type: "s3-compatible",
    bucket,
    endpoint,
    region,
    // Designed for presigned URL workflows.
    async putWithPresignedUrl(url, content, contentType = "application/octet-stream") {
      const res = await fetch(url, { method: "PUT", headers: { "content-type": contentType }, body: content });
      if (!res.ok) throw new Error(`S3 upload failed: ${res.status}`);
      return true;
    },
    async getWithPresignedUrl(url) {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`S3 download failed: ${res.status}`);
      return Buffer.from(await res.arrayBuffer());
    },
    presignPath(key, action = "get") {
      if (!presignBaseUrl) throw new Error("presignBaseUrl is required for presignPath");
      return `${presignBaseUrl}?bucket=${encodeURIComponent(bucket)}&key=${encodeURIComponent(key)}&action=${encodeURIComponent(action)}`;
    },
  };
}
