﻿import { createServer } from "node:http";
import { existsSync, readFileSync, statSync, watch } from "node:fs";
import { extname, join, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { runBuild } from "./build.mjs";
import { parseCookies, serializeCookie, createSessionManager, requireUser } from "./auth.mjs";
import { createFileDatabase } from "./db.mjs";
import { createPostgresCollectionDatabase } from "./db-postgres-collection.mjs";
import { composeMiddleware } from "./middleware.mjs";
import { readJsonBody, validateShape } from "./validation.mjs";
import { loadEnv, validateAppEnv } from "./env.mjs";
import { createLogger } from "./logger.mjs";
import { createJobQueue } from "./jobs.mjs";
import { securityHeaders, rateLimit, csrf } from "./security.mjs";
import { createFileCache, createRedisCache } from "./cache.mjs";
import { createTracer } from "./observability.mjs";
import { createLocalStorage, createS3CompatibleStorage } from "./storage.mjs";
import { createPluginRuntime } from "./plugins.mjs";
import { createMetricsStore } from "./metrics.mjs";

const DIST_DIR = resolve("dist");
const DB_DIR = resolve(".fastscript");

function setupAppWatcher(onChange, logger) {
  const appRoot = resolve("app");
  if (!existsSync(appRoot)) return () => {};
  try {
    const watcher = watch(appRoot, { recursive: true }, onChange);
    return () => watcher.close();
  } catch (error) {
    logger.warn("recursive_watch_unavailable", { error: error?.message || String(error) });
    const watcher = watch(appRoot, onChange);
    return () => watcher.close();
  }
}

function contentType(path) {
  const ext = extname(path);
  if (ext === ".html") return "text/html; charset=utf-8";
  if (ext === ".js") return "application/javascript; charset=utf-8";
  if (ext === ".css") return "text/css; charset=utf-8";
  if (ext === ".json") return "application/json; charset=utf-8";
  if (ext === ".map") return "application/json; charset=utf-8";
  return "text/plain; charset=utf-8";
}

function readManifest() {
  const path = join(DIST_DIR, "fastscript-manifest.json");
  return JSON.parse(readFileSync(path, "utf8"));
}

function match(routePath, pathname) {
  const a = routePath.split("/").filter(Boolean);
  const b = pathname.split("/").filter(Boolean);
  if (a.length !== b.length) return null;
  const params = {};
  for (let i = 0; i < a.length; i += 1) {
    if (a[i].startsWith(":")) params[a[i].slice(1)] = b[i];
    else if (a[i] !== b[i]) return null;
  }
  return params;
}

function resolveRoute(routes, pathname) {
  for (const route of routes) {
    const params = match(route.path, pathname);
    if (params) return { route, params };
  }
  return null;
}

async function importDist(modulePath) {
  const abs = join(DIST_DIR, modulePath.replace(/^\.\//, ""));
  const url = `${pathToFileURL(abs).href}?t=${Date.now()}`;
  return import(url);
}

function createHelpers(res, { secureCookies = false } = {}) {
  return {
    json(body, status = 200, headers = {}) {
      return { status, json: body, headers };
    },
    text(body, status = 200, headers = {}) {
      return { status, body, headers };
    },
    redirect(location, status = 302) {
      return { status, headers: { location } };
    },
    setCookie(name, value, opts = {}) {
      const current = res.getHeader("set-cookie");
      const next = serializeCookie(name, value, {
        sameSite: "Lax",
        secure: secureCookies,
        ...opts,
      });
      if (!current) res.setHeader("set-cookie", [next]);
      else res.setHeader("set-cookie", Array.isArray(current) ? [...current, next] : [String(current), next]);
    },
  };
}

function writeResponse(res, payload) {
  if (!payload) {
    res.writeHead(204);
    res.end();
    return;
  }
  const status = payload.status ?? 200;
  const headers = payload.headers ?? {};
  if (payload.cookies && payload.cookies.length) headers["set-cookie"] = payload.cookies;
  if (payload.json !== undefined) {
    res.writeHead(status, { "content-type": "application/json; charset=utf-8", ...headers });
    res.end(JSON.stringify(payload.json));
    return;
  }
  res.writeHead(status, { "content-type": "text/plain; charset=utf-8", ...headers });
  res.end(payload.body ?? "");
}

function htmlDoc(content, ssrData, hasStyles) {
  const safe = JSON.stringify(ssrData ?? {}).replace(/</g, "\\u003c");
  return `<!doctype html>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>FastScript</title>
    ${hasStyles ? '<link rel="stylesheet" href="/styles.css" />' : ""}
  </head>
  <body>
    <div id="app">${content}</div>
    <script>window.__FASTSCRIPT_SSR=${safe}</script>
    <script type="module" src="/router.js"></script>
  </body>
</html>`;
}

export async function runServer({ mode = "development", watchMode = false, buildOnStart = true, port = 4173 } = {}) {
  loadEnv({ mode });
  await validateAppEnv();

  const isProduction = (mode || process.env.NODE_ENV || "development") === "production";
  const sessionSecret = process.env.SESSION_SECRET || "";
  if (isProduction && !sessionSecret) {
    throw new Error("Missing SESSION_SECRET in production.");
  }

  const logger = createLogger({ service: "fastscript-server" });
  const tracer = createTracer({ service: "fastscript-server" });
  const plugins = await createPluginRuntime({ logger });
  const metrics = createMetricsStore({ dir: DB_DIR, name: "metrics" });
  if (buildOnStart) await runBuild();

  const sessions = createSessionManager({ dir: DB_DIR, cookieName: "fs_session", secret: sessionSecret || "fastscript-dev-secret" });
  let db = createFileDatabase({ dir: DB_DIR, name: "appdb" });
  if ((process.env.DB_DRIVER || "").toLowerCase() === "postgres") {
    try {
      db = await createPostgresCollectionDatabase({ connectionString: process.env.DATABASE_URL });
      logger.info("db_driver", { driver: "postgres" });
    } catch (error) {
      logger.warn("db_driver_fallback", { driver: "file", error: error?.message || String(error) });
      db = createFileDatabase({ dir: DB_DIR, name: "appdb" });
    }
  }
  const queue = createJobQueue({ dir: DB_DIR });

  let cache = createFileCache({ dir: join(DB_DIR, "cache") });
  if ((process.env.CACHE_DRIVER || "").toLowerCase() === "redis") {
    try {
      cache = await createRedisCache({ url: process.env.REDIS_URL });
      logger.info("cache_driver", { driver: "redis" });
    } catch (error) {
      logger.warn("cache_driver_fallback", { driver: "file", error: error?.message || String(error) });
    }
  }

  let storage = createLocalStorage({ dir: join(DB_DIR, "storage") });
  if ((process.env.STORAGE_DRIVER || "").toLowerCase() === "s3") {
    const bucket = process.env.STORAGE_S3_BUCKET;
    const endpoint = process.env.STORAGE_S3_ENDPOINT;
    const presignBaseUrl = process.env.STORAGE_S3_PRESIGN_BASE_URL;
    if (bucket && endpoint && presignBaseUrl) {
      storage = createS3CompatibleStorage({ bucket, endpoint, presignBaseUrl, region: process.env.STORAGE_S3_REGION || "auto" });
      logger.info("storage_driver", { driver: "s3-compatible" });
    } else {
      logger.warn("storage_driver_fallback", { driver: "local", reason: "missing_s3_env" });
    }
  }
  let stopWatching = null;

  if (watchMode) {
    let timer = null;
    stopWatching = setupAppWatcher(() => {
      clearTimeout(timer);
      timer = setTimeout(async () => {
        try {
          await runBuild();
          logger.info("rebuild complete");
        } catch (error) {
          logger.error("rebuild failed", { error: error.message });
        }
      }, 120);
    }, logger);
  }

  const server = createServer(async (req, res) => {
    const requestId = logger.requestId();
    const start = Date.now();
    const span = tracer.span("request", { requestId, path: req.url, method: req.method });
    res.setHeader("x-request-id", requestId);
    let responseStatus = 500;
    let responseKind = "error";
    let responseError = null;
    let requestCtx = null;

    try {
      const url = new URL(req.url || "/", "http://localhost");
      const pathname = url.pathname;
      const method = (req.method || "GET").toUpperCase();
      const manifest = readManifest();
      const helpers = createHelpers(res, { secureCookies: isProduction });
      requestCtx = { requestId, pathname, method, mode };
      await plugins.onRequestStart(requestCtx);
      const cookies = parseCookies(req.headers.cookie || "");
      const session = sessions.read(cookies[sessions.cookieName]);
      sessions.sweepExpired();

      const ctx = {
        req,
        res,
        requestId,
        pathname,
        method,
        params: {},
        query: Object.fromEntries(url.searchParams.entries()),
        cookies,
        user: session?.user ?? null,
        db,
        queue,
        cache,
        storage,
        auth: {
          login: (user, opts = {}) => {
            const token = sessions.create(user, opts.maxAge ?? 60 * 60 * 24 * 7);
            helpers.setCookie(sessions.cookieName, token, { path: "/", httpOnly: true, maxAge: opts.maxAge ?? 60 * 60 * 24 * 7 });
            return token;
          },
          logout: () => {
            sessions.delete(cookies[sessions.cookieName]);
            helpers.setCookie(sessions.cookieName, "", { path: "/", httpOnly: true, maxAge: 0 });
          },
          requireUser: () => requireUser(session?.user ?? null),
          rotate: (opts = {}) => {
            const token = sessions.rotate(cookies[sessions.cookieName], opts.maxAge ?? 60 * 60 * 24 * 7);
            if (token) helpers.setCookie(sessions.cookieName, token, { path: "/", httpOnly: true, maxAge: opts.maxAge ?? 60 * 60 * 24 * 7 });
            return token;
          },
        },
        input: {
          body: null,
          query: Object.fromEntries(url.searchParams.entries()),
          async readJson() {
            if (ctx.input.body !== null) return ctx.input.body;
            ctx.input.body = await readJsonBody(req, { maxBytes: Number(process.env.MAX_BODY_BYTES || 1024 * 1024) });
            return ctx.input.body;
          },
          validateQuery(schema) {
            return validateShape(schema, ctx.query, "query").value;
          },
          async validateBody(schema) {
            const body = await ctx.input.readJson();
            return validateShape(schema, body, "body").value;
          },
        },
        helpers,
      };

      const isBodyMethod = !["GET", "HEAD"].includes(ctx.method);
      const contentTypeHeader = String(req.headers["content-type"] || "");
      if (isBodyMethod && contentTypeHeader.includes("application/json")) {
        ctx.input.body = await ctx.input.readJson();
      }

      const target = join(DIST_DIR, pathname === "/" ? "index.html" : pathname.slice(1));
      if (pathname === "/__metrics" && process.env.METRICS_PUBLIC === "1") {
        writeResponse(res, { status: 200, json: metrics.snapshot() });
        responseStatus = 200;
        responseKind = "metrics";
        span.end({ status: 200, kind: "metrics" });
        return;
      }
      if (pathname.startsWith("/__storage/")) {
        const key = decodeURIComponent(pathname.slice("/__storage/".length));
        const file = storage.get(key);
        if (!file) {
          writeResponse(res, { status: 404, body: "Not found" });
          responseStatus = 404;
          responseKind = "storage";
          span.end({ status: 404, kind: "storage" });
          return;
        }
        res.writeHead(200, { "content-type": "application/octet-stream" });
        res.end(file);
        responseStatus = 200;
        responseKind = "storage";
        span.end({ status: 200, kind: "storage" });
        return;
      }
      if (existsSync(target) && statSync(target).isFile() && !pathname.endsWith(".html")) {
        const body = readFileSync(target);
        res.writeHead(200, { "content-type": contentType(target) });
        res.end(body);
        logger.info("static", { requestId, path: pathname, status: 200, ms: Date.now() - start });
        responseStatus = 200;
        responseKind = "static";
        span.end({ status: 200, kind: "static" });
        return;
      }

      const middlewareList = [];
      middlewareList.push(securityHeaders(), rateLimit());
      if (process.env.CSRF_PROTECT !== "0") middlewareList.push(csrf());
      const pluginMiddleware = plugins.middleware();
      if (pluginMiddleware.length) middlewareList.push(...pluginMiddleware);
      if (manifest.middleware) {
        const mm = await importDist(manifest.middleware);
        if (Array.isArray(mm.middlewares)) middlewareList.push(...mm.middlewares);
        else if (typeof mm.middleware === "function") middlewareList.push(mm.middleware);
        else if (typeof mm.default === "function") middlewareList.push(mm.default);
      }
      const runWithMiddleware = composeMiddleware(middlewareList);

      const out = await runWithMiddleware(ctx, async () => {
        if (pathname.startsWith("/api/")) {
          const apiHit = resolveRoute(manifest.apiRoutes, pathname);
          if (!apiHit) return { status: 404, body: "API route not found" };
          ctx.params = apiHit.params;
          const mod = await importDist(apiHit.route.module);
          const handler = mod[ctx.method];
          if (typeof handler !== "function") return { status: 405, body: `Method ${ctx.method} not allowed` };
          if (mod.schemas?.[ctx.method]) {
            ctx.input.body = await ctx.input.readJson();
            validateShape(mod.schemas[ctx.method], ctx.input.body, "body");
          }
          return handler(ctx, helpers);
        }

        const hit = resolveRoute(manifest.routes, pathname);
        if (!hit) {
          if (manifest.notFound) {
            const nfMod = await importDist(manifest.notFound);
            const body = nfMod.default ? nfMod.default({ pathname }) : "<h1>404</h1>";
            return { status: 404, html: body, data: null };
          }
          return { status: 404, body: "Not found" };
        }

        ctx.params = hit.params;
        const mod = await importDist(hit.route.module);

        if (!["GET", "HEAD"].includes(ctx.method) && typeof mod[ctx.method] === "function") {
          if (mod.schemas?.[ctx.method]) {
            ctx.input.body = await ctx.input.readJson();
            validateShape(mod.schemas[ctx.method], ctx.input.body, "body");
          }
          return mod[ctx.method](ctx, helpers);
        }

        let data = {};
        if (typeof mod.load === "function") data = (await mod.load({ ...ctx, params: hit.params, pathname })) || {};
        let html = mod.default ? mod.default({ ...data, params: hit.params, pathname, user: ctx.user }) : "";

        if (manifest.layout) {
          const layout = await importDist(manifest.layout);
          html = layout.default ? layout.default({ content: html, pathname, user: ctx.user }) : html;
        }

        return { status: 200, html, data };
      });

      if (out?.html !== undefined) {
        const hasStyles = existsSync(join(DIST_DIR, "styles.css"));
        const payload = { pathname, data: out.data ?? null };
        responseStatus = out.status ?? 200;
        responseKind = "ssr";
        res.writeHead(responseStatus, { "content-type": "text/html; charset=utf-8" });
        res.end(htmlDoc(out.html, payload, hasStyles));
        logger.info("ssr", { requestId, path: pathname, status: responseStatus, ms: Date.now() - start });
        span.end({ status: responseStatus, kind: "ssr" });
        return;
      }

      writeResponse(res, out);
      responseStatus = out?.status ?? 200;
      responseKind = "response";
      logger.info("response", { requestId, path: pathname, status: responseStatus, ms: Date.now() - start });
      span.end({ status: responseStatus, kind: "response" });
    } catch (error) {
      const status = error?.status && Number.isInteger(error.status) ? error.status : 500;
      const payload = {
        ok: false,
        error: {
          message: error?.message || "Unknown error",
          status,
          details: error?.details || null,
        },
      };
      const wantsJson = (req.headers.accept || "").includes("application/json") || (req.url || "").startsWith("/api/");
      if (wantsJson) {
        res.writeHead(status, { "content-type": "application/json; charset=utf-8" });
        res.end(JSON.stringify(payload));
      } else {
        res.writeHead(status, { "content-type": "text/html; charset=utf-8" });
        res.end(`<!doctype html><html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/><title>Error</title><style>body{background:#050505;color:#fff;font:16px/1.6 ui-sans-serif,system-ui;padding:40px}code{color:#9f92ff}</style></head><body><h1>Something went wrong</h1><p>Please retry or roll back to the previous deploy.</p><p>Request ID: <code>${requestId}</code></p></body></html>`);
      }
      responseStatus = status;
      responseKind = "error";
      responseError = payload.error.message;
      logger.error("request_error", { requestId, status, path: req.url, error: payload.error.message });
      span.end({ status, error: payload.error.message, kind: "error" });
    } finally {
      const durationMs = Date.now() - start;
      metrics.inc("requests_total", 1);
      metrics.inc(`requests_status_${responseStatus}`, 1);
      metrics.inc(`requests_kind_${responseKind}`, 1);
      if (responseError) metrics.inc("requests_error_total", 1);
      metrics.observe("request_duration_ms", durationMs);
      try {
        await plugins.onRequestEnd({
          ...(requestCtx || { requestId, pathname: req.url || "/", method: req.method || "GET", mode }),
          status: responseStatus,
          kind: responseKind,
          error: responseError,
          durationMs,
        });
      } catch (hookError) {
        logger.warn("plugin_on_request_end_failed", { error: hookError?.message || String(hookError) });
      }
    }
  });
  const requestTimeoutMs = Number(process.env.REQUEST_TIMEOUT_MS || 15000);
  if (Number.isFinite(requestTimeoutMs) && requestTimeoutMs > 0) {
    server.requestTimeout = requestTimeoutMs;
  }

  server.listen(port, () => {
    logger.info("server_started", { mode, port, watchMode });
  });

  function cleanup() {
    if (stopWatching) {
      stopWatching();
      stopWatching = null;
    }
    if (db && typeof db.flush === "function") {
      Promise.resolve(db.flush()).catch(() => {});
    }
    if (db && typeof db.close === "function") {
      Promise.resolve(db.close()).catch(() => {});
    }
    if (cache && typeof cache.close === "function") {
      Promise.resolve(cache.close()).catch(() => {});
    }
  }
  process.once("SIGINT", cleanup);
  process.once("SIGTERM", cleanup);

  return server;
}
